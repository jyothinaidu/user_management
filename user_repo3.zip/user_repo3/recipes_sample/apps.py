from django.apps import AppConfig


class RecipesSampleConfig(AppConfig):
    name = 'recipes_sample'
