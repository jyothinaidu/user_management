from django.apps import AppConfig


class DataApiConfig(AppConfig):
    name = 'recipe_api'



